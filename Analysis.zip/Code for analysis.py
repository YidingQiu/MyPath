# -*- coding: utf-8 -*-
"""
Standard linear regression; note that there exists a weak negative linear correlation 
between SEIFA DIS rank within the state and expenditure per adult, and a fairly 
strong positive linear correlation between unemployment rate and expenditure per adult. 
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import seaborn as sns
import matplotlib.pyplot as plt

start_path = "C:/Users/quick/OneDrive/Documents/Govhack/Gambling data/"
LGA_yearly = pd.read_excel(start_path + "yearly_density_statistical_release_nov_24-(2).xlsx", sheet_name = "2023-24")
LGA_rents = pd.read_excel(start_path + "Quarterly-median-rents-by-Local-Government-Area-September-quarter-2024.xlsx", sheet_name = "All Properties")

renaming = []
# Renaming the LGA names in the rental data
# Note that this also required the following manual changes in the Excel data:
#   - In the rental dataset "Merri-bek" was renamed to "Moreland"
#   - In the rental dataset "Mornington Penin'a" was renamed to "Mornington Peninsula"
for name in LGA_yearly['LGA Name']:
    if "of" in name:
        name_update = name[name.find("of"):]
        renaming.append(name_update.replace("of ", ""))
    else:
        renaming.append(name)
LGA_yearly['LGA Name'] = renaming

# Obtaining the datasets
comb = pd.merge(LGA_yearly, LGA_rents[['LGA Name', 'Median rent across FY']], on = "LGA Name")
y = np.array(comb['Expenditure ($) per Adult 2024']).reshape(-1, 1)
x1 = np.array(comb['SEIFA DIS Rank State']).reshape(-1, 1)

# This one is for unemployment rates and rental prices
x2 = comb[['Unemployment Rate as at June 2024', 'Median rent across FY']]

# Initial linear analysis - this is mainly used for the presentation to show that we've found some potential risk factors
plt.figure()
plot = sns.lmplot(x = 'SEIFA DIS Rank State', y = 'Expenditure ($) per Adult 2024', data = comb, fit_reg = True, ci=95, n_boot = 1000)
plt.xlabel('SEIFA rank (DISADV) - higher value is less disadvantaged')
plt.ylabel('Average expenditure per adult')
plt.title('SEIFA rank (DISADV) against average expenditure')
plot.tight_layout(pad=3.0)
plt.savefig('SEIFA vs Average Expenditure.png')
plt.close()

plt.figure()
plot = sns.lmplot(x = 'Unemployment Rate as at June 2024', y = 'Expenditure ($) per Adult 2024', data = comb, fit_reg = True, ci=95, n_boot = 1000)
plt.xlabel('Unemployment rate')
plt.ylabel('Average expenditure per adult')
plt.title('Unemployment rate against average expenditure')
plot.tight_layout(pad=3.0)
plt.savefig('Unemployment vs Average Expenditure.png')
plt.close()

plt.figure()
plot = sns.lmplot(x = 'Median rent across FY', y = 'Expenditure ($) per Adult 2024', data = comb, fit_reg = True, ci=95, n_boot = 1000)
plt.xlabel('Median rent')
plt.ylabel('Average gambling expenditure per adult')
plt.title('Rent against average expenditure')
plot.tight_layout(pad=3.0)
plt.savefig('Rent vs Average Expenditure.png')
plt.close()

# This is to construct more detailed linear models. As SEIFA ranking is a PCA aggregate of a lot of factors including rent and unemployment rate, x1 is 
# more to see if there exists a correlation between overall socioeconomic factors and average gambling expenditure. x2 looks specifically at rent and
# unemployment rate. 
reg1 = LinearRegression().fit(x1, y)
x2_vars = x2[['Unemployment Rate as at June 2024', 'Median rent across FY']]
reg2 = LinearRegression().fit(x2_vars, y)
pred1 = reg1.coef_[0][0]*x1 + reg1.intercept_[0]
pred2 = reg2.coef_[0]*x2 + reg2.intercept_[0]

# Checking for approximate linearity by observing plots of residuals against independent variables - no issues found
res1 = pred1 - y
plt.figure()
plt.xlabel('SEIFA rank')
plt.ylabel('Residuals')
plt.plot(x1, res1, 'o')
plt.plot(x1, x1*0)
plt.title('Residuals - SEIFA')
plot.tight_layout(pad=3.0)
plt.savefig('Residuals - SEIFA.png')
plt.close()

# Plots of residuals are not symmetric about zero for both variables; indicates that a multiple linear regression is unlikely to be appropriate. There
# is also no clear pattern in both plots of residuals, so performing a nonlinear transformation of the variables is unlikely to resolve the issue. It is 
# possible that this is due to collinearity between rents and unemployment rate. 
res_unemp = pred2['Unemployment Rate as at June 2024'] - comb['Expenditure ($) per Adult 2024']
plt.figure()
plt.xlabel('Unemployment rate')
plt.ylabel('Residuals')
plt.plot(x2['Unemployment Rate as at June 2024'], res_unemp, 'o')
plt.plot(x2['Unemployment Rate as at June 2024'], x2['Unemployment Rate as at June 2024']*0)
plt.title('Residuals - unemployment (multiple linear regression)')
plt.savefig('Residuals - Unemployment (Multiple).png')
plt.close()

res_rent = pred2['Median rent across FY'] - comb['Expenditure ($) per Adult 2024']
plt.figure()
plt.xlabel('Median Rent')
plt.ylabel('Residuals')
plt.plot(x2['Median rent across FY'], res_unemp, 'o')
plt.plot(x2['Median rent across FY'], x2['Median rent across FY']*0)
plt.title('Residuals - rent (multiple linear regression)')
plt.savefig('Residuals - Rent (Multiple).png')
plt.close()

# If we construct plots of residuals of the simple linear regressions against each individual variable, we find that the residual plots are indeed symmetric 
# about zero. This suffices to at least show these are risk factors as there exists a positive correlation. 
reg_unemp = LinearRegression().fit(np.array(x2['Unemployment Rate as at June 2024']).reshape(-1, 1), y)
reg_rent = LinearRegression().fit(np.array(x2['Median rent across FY']).reshape(-1, 1), y)
pred_unemp = reg_unemp.coef_[0][0]*x2['Unemployment Rate as at June 2024'] + reg_unemp.intercept_[0]
pred_rent = reg_rent.coef_[0][0]*x2['Median rent across FY'] + reg_unemp.intercept_[0]

# 
res_unemp = pred_unemp - comb['Expenditure ($) per Adult 2024']
plt.figure()
plt.xlabel('Unemployment rate')
plt.ylabel('Residuals')
plt.plot(x2['Unemployment Rate as at June 2024'], res_unemp, 'o')
plt.plot(x2['Unemployment Rate as at June 2024'], x2['Unemployment Rate as at June 2024']*0)
plt.title('Residuals - unemployment (simple linear regression)')
plt.savefig('Residuals - Unemployment (Simple).png')
plt.close()

res_rent = pred_rent - comb['Expenditure ($) per Adult 2024']
plt.figure()
plt.xlabel('Median Rent')
plt.ylabel('Residuals')
plt.plot(x2['Median rent across FY'], res_rent, 'o')
plt.plot(x2['Median rent across FY'], x2['Median rent across FY']*0)
plt.title('Residuals - rent (simple linear regression)')
plt.savefig('Residuals - Rent (Simple).png')
plt.close()

"""
Very elementary time series analysis; basically I want to see what are the times
that tend to have higher rates of gambling. 
Interesting observations: 
    - In both the 2023-24 and 2024-25 FYs, there is a large dip from Aug to Sep and a very large dip from Dec to Feb, followed by a major climb from Feb to Mar
    - In 2023-24 there was also a large bump from Nov to Dec. 
    - Overall, there were increased losses throughout the year. 
"""

monthly_2425_raw = pd.read_excel(start_path + "current_monthly_lga_data_release.xlsx", sheet_name = "2024-25")
monthly_2324_raw = pd.read_excel(start_path + "current_monthly_lga_data_release.xlsx", sheet_name = "2023-24")

# Obtaining the average loss per machine on a monthly basis
monthly_2425 = monthly_2425_raw.iloc[:, 5::4]
monthly_2425.insert(loc = 0, column = 'LGA Name', value = monthly_2425_raw['LGA Name'])
monthly_2324 = monthly_2324_raw.iloc[:, 5::4]
monthly_2324.insert(loc = 0, column = 'LGA Name', value = monthly_2425_raw['LGA Name'])

# Plots the individual time series
months = ["Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May", "Jun"]
plt.figure()
plt.plot(months, monthly_2425.iloc[57][1:13])
plt.xlabel('Month')
plt.ylabel('Average loss per machine')
plt.title('2024-25 Time Series')
plt.savefig('2024-25 Time Series.png')
plt.close()

plt.figure()
plt.plot(months, monthly_2324.iloc[57][1:13])
plt.xlabel('Month')
plt.ylabel('Average loss per machine')
plt.title('2023-24 Time Series')
plt.savefig('2023-24 Time Series.png')
plt.close()

# Plots the time series overlayed on top of each other
plt.figure()
plt.plot(months, monthly_2425.iloc[57][1:13], label='2024-25')
plt.plot(months, monthly_2324.iloc[57][1:13], label='2023-24')
plt.xlabel('Month')
plt.ylabel('Average loss per machine')
plt.legend(loc='upper right')
plt.title('Overlaid Time Series')
plt.savefig('Overlaid Time Series.png')
plt.close()